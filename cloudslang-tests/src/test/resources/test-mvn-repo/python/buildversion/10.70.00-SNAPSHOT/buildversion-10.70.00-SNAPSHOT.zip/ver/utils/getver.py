import version.utils.setversion as version

def get_ver(var1, var2):
	return version.full_version('[' + str(var1) + '*' + str(var2) + ']')
